let chosenNumber = Math.floor(Math.random()*2);
let secondchosenNumber = Math.floor(Math.random()*2);
let thridchosenNumber = Math.floor(Math.random()*2);
let fourthchosenNumber = Math.floor(Math.random()*2);
let fifthchosenNumber = Math.floor(Math.random()*2);
console.log(chosenNumber, secondchosenNumber, thridchosenNumber,fourthchosenNumber,fifthchosenNumber);

if (chosenNumber==1 && secondchosenNumber==1 && thridchosenNumber==1 && fourthchosenNumber==1 && fifthchosenNumber==1)
{console.log('Congratulations! You have won jackpot!!')
}else if  (chosenNumber==0 && secondchosenNumber==0 && thridchosenNumber==0 && fourthchosenNumber==0 && fifthchosenNumber==0)
{console.log("Congratulations, gettin five zero´s is as hard as gettin five one´s, unfortunately you still don´t will anything")
}

console.log("change´s getting five numbers as same is")+console.log(2**5)


